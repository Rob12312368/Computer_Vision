1. The threshold I used is 0.5.
2. The combination criteria I used is that the difference of roundness should be smaller than 0.09, and
the quotient of minimum moment of inertia should be smaller than 0.8.
